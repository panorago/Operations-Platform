import{Z as c,$ as f}from"./index-CER2AArr.js";function D(t,a,e){const r=c(t,e==null?void 0:e.in);return isNaN(a)?f(t,NaN):(a&&r.setDate(r.getDate()+a),r)}export{D as a};
