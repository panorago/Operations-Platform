export { useInventoryStore } from "./index";
