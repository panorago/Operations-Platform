export { useProductStore } from "./index";
